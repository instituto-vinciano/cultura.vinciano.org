Paraíba Ponto Cultural - template estático inspirado na estrutura do Opera Mundi.
Substitua os arquivos em assets/images/logo.svg e as imagens placeholder conforme necessário.
Estrutura:
- index.html
- posts/post-01.html ... post-05.html
- assets/css/style.css
- assets/images/*.svg
